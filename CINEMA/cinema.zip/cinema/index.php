<?php
// Recuperation des models
require_once("./Models/Database.class.php");
require_once("./Models/Film.class.php");
require_once("./Models/Genre.class.php");

// Recuperation du helper
require_once("./helper.php");

// Logique de code
$modelFilm = new Film;
$modelGenre = new Genre;

if (!empty($_GET['search'])) {
    $films = $modelFilm->getByName($_GET['search']);
} elseif (!empty($_GET['genre'])) {
    $films = $modelFilm->getByGenre($_GET['genre']);
} 
else {
    $films = $modelFilm->getAll();
}

$genres = $modelGenre->getAll();

// Inclusion du HTML
include_once("./Views/home.php");