<?php

class Film extends Database {
    private $base = "SELECT film.*, genre.nom AS genre, distrib.nom as distrib
                    FROM film
                    LEFT JOIN genre ON film.genre_id = genre.id 
                    LEFT JOIN distrib ON film.distrib_id = distrib.id ";


    public function getAll() {
        $request = $this->db->prepare($this->base . "LIMIT 20");

        $request->execute();

        $data = $request->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function getByName($name) {
        $request = $this->db->prepare($this->base . "WHERE titre LIKE :name LIMIT 20");

        $request->execute([
            'name' => '%' . $name . '%'
        ]);

        $data = $request->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }

    public function getByGenre($genre_id) {
        $request = $this->db->prepare($this->base . "WHERE genre_id = :genre_id LIMIT 20");

        $request->execute([
            'genre_id' =>  $genre_id 
        ]);

        $data = $request->fetchAll(PDO::FETCH_ASSOC);

        return $data;
    }
}